<?php

class User extends ActiveRecord\Model { }