<?php

class Post extends ActiveRecord\Model { }