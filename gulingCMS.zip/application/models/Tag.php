<?php

class Tag extends ActiveRecord\Model { }