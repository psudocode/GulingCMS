<?php

class Post_to_tag extends ActiveRecord\Model { }