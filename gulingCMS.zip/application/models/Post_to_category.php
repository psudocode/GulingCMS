<?php

class Post_to_category extends ActiveRecord\Model { }