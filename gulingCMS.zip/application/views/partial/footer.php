<div class="container">
    <div class="col-lg-12">
        <nav class="navbar navbar-default small" role="navigation">
            <div class="text-center small">Copyright@<?= date('Y') ?> idtut.com All right reserved</div>
            <div class="text-center small">Powered By <a href="https://github.com/psudocode/GulingCMS">GulingCMS</a></div>
        </nav>
    </div>
</div>
