
<pre>
    <?php var_dump($this->session->all_userdata()); ?>
</pre>
