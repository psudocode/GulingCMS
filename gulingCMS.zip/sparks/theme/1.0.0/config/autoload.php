<?php

# Load the theme config
$autoload['config'] = array('theme');

# Load the theme spark
$autoload['libraries'] = array('theme');
