<h1>Theme example</h1>

<small>This view is loaded from <strong>application/view/theme_example</strong></small>

<p>From this theme example you can choose out of two themes:</p>

<p>
	The first one (the default) is based on:
	<?php echo anchor('theme_example/switch_theme/default', 'Bootstrap', 'class="button btn"'); ?>
</p>

<p>
	The second one is based on:
	<?php echo anchor('theme_example/switch_theme/skeleton', 'Skeleton', 'class="button btn"'); ?>
</p>
