<?php

$autoload['libraries'] = array('PHPActiveRecord');
