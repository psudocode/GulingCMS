# GulingCMS

**GulingCMS** adalah Mini CMS untuk kebutuhan belajar, Berdiri diatas Framework Codeigniter dan menggunakan Spark Library. 

Future Feature : 
- [x] Templating Support, 
- [x] Simple and Clean Content Management, we call it **klimis** 
- [ ] Clean Documentation (Under Dev), 
- [ ] Pluggin System, etc.

<strong>WARNING GulingCMS NOT YET FINISHED, AND STILL UNDER DEVELOPMENT.</strong>


**__GulingCMS by Ahmad Awdiyanto__**
http://www.idtut.com
