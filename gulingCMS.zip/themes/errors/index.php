<!DOCTYPE html>

<html>

    <head></head>
    <body>
        <div style="font-family: verdana; color: #ccc; text-align: center">
            <h1 style="line-height: 10px; color: #aaa;"><?php echo $this->content(); ?></h1>
            <h2 style="line-height: 18px; margin-bottom: 5px">Sorry! Gue lagi sibuk belajar fisika,</h2>
            <span>jadi ga ada waktu buat bikin halaman yang lo tuju.</span><br />
            <img alt="Page Not Found (404)." src="http://cdn.css-tricks.com/images/404.jpg"></img>

        </div>
    </body>

</html>